# Node.js Security Starter (Beginner Project)

A small Express API demonstrating the practices covered by the linked **Node.js Security Best Practices for Beginners (2025)** video: validation, password hashing, secret management, SQL-injection prevention, security headers, rate limiting, dependency auditing, and safe error handling.

Video: https://www.youtube.com/watch?v=BbbOPxzK5EY

## Features

- **Input validation:** Zod schemas validate and constrain request bodies; unknown fields are rejected.
- **Password security:** passwords are hashed with bcryptjs; plaintext passwords are never stored.
- **Secrets:** configuration comes from `.env`; `.env` is ignored by Git and must never be committed.
- **SQL injection defense:** PostgreSQL queries use `$1`, `$2` parameter placeholders.
- **HTTP security:** Helmet sets security headers; CORS allows only the configured frontend origin.
- **Abuse protection:** global API and stricter authentication rate limits; JSON body size is capped.
- **JWT authentication:** short-lived signed tokens, explicit HS256 verification, protected `/me` endpoint.
- **Safe errors:** client responses do not expose stack traces or database details.
- **Dependency hygiene:** `npm audit` script and beginner test suite.

## Requirements

- Node.js 20+
- PostgreSQL 14+ (local or managed)

## Setup

1. Extract the ZIP and open the project folder in a terminal.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Create a PostgreSQL database named `security_demo`, or update `DATABASE_URL` for your database.
4. Copy `.env.example` to `.env`.
5. Set a strong random `JWT_SECRET` (at least 32 characters). For example, generate one with:

   ```bash
   node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
   ```

6. Update `DATABASE_URL` and `CORS_ORIGIN` in `.env`.
7. Start the API:

   ```bash
   npm run dev
   ```

The server starts at `http://localhost:3000`. The users table is created automatically.

## API examples

### Health check

```bash
curl http://localhost:3000/health
```

### Register

Password must be at least 12 characters.

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"learner@example.com","password":"CorrectHorseBatteryStaple!"}'
```

### Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"learner@example.com","password":"CorrectHorseBatteryStaple!"}'
```

Copy the returned token and use it below.

### Current user

```bash
curl http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Run tests and audit dependencies

```bash
npm test
npm audit
```

Review and update dependencies regularly. Do not blindly run `npm audit fix --force` because it can introduce breaking changes.

## HTTPS and production notes

This starter is intended for local learning. In production:

- Terminate HTTPS at a trusted reverse proxy or platform load balancer; redirect HTTP to HTTPS and enable HSTS only after HTTPS is correctly configured.
- Keep `NODE_ENV=production`; use a managed secret store and a unique JWT secret.
- Configure database TLS with certificate verification; do not disable certificate checks.
- Put the API behind a trusted proxy and configure Express `trust proxy` narrowly before relying on client IP rate limits.
- Use a token revocation/refresh strategy if your application needs logout or long sessions. This demo uses short-lived bearer tokens and does not implement refresh tokens.
- Add monitoring, backups, least-privilege database credentials, CI security scans, and an appropriate Content Security Policy for your frontend.
- For browser-based authentication, consider secure, HttpOnly, SameSite cookies plus CSRF protection rather than storing bearer tokens in browser local storage.

## Project structure

```text
nodejs-security-starter/
├── src/
│   ├── routes/auth.js
│   ├── config.js
│   ├── db.js
│   ├── middleware.js
│   └── server.js
├── sql/init.sql
├── test/security.test.js
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Learning checklist

- [ ] Install Node.js and PostgreSQL
- [ ] Configure `.env` without committing secrets
- [ ] Register and log in a test user
- [ ] Inspect the database and confirm only a password hash is stored
- [ ] Try invalid email and short password inputs
- [ ] Try `/api/auth/me` without a token, then with a valid token
- [ ] Review response headers for Helmet protections
- [ ] Run `npm test` and `npm audit`

Educational starter only; review and test it against your application's threat model before production use.
