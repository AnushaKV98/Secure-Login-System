import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('server enables Helmet and limits JSON request bodies', async () => {
  const source = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.match(source, /app\.use\(helmet\(\)\)/);
  assert.match(source, /express\.json\(\{ limit: '10kb'/);
});

test('auth routes use parameterized SQL and bcrypt password hashing', async () => {
  const source = await readFile(new URL('../src/routes/auth.js', import.meta.url), 'utf8');
  assert.match(source, /bcrypt\.hash/);
  assert.match(source, /VALUES \(\$1, \$2\)/);
  assert.match(source, /WHERE email = \$1/);
});

test('JWT verification restricts accepted algorithm', async () => {
  const source = await readFile(new URL('../src/middleware.js', import.meta.url), 'utf8');
  assert.match(source, /algorithms: \['HS256'\]/);
});
