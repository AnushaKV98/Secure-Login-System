import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { pool } from '../db.js';
import { config } from '../config.js';
import { authLimiter, requireAuth } from '../middleware.js';

const router = Router();
const credentials = z.object({
  email: z.string().trim().email().max(254).transform(v => v.toLowerCase()),
  password: z.string().min(12).max(128)
}).strict();

router.post('/register', authLimiter, async (req, res, next) => {
  try {
    const parsed = credentials.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid registration data.', details: parsed.error.flatten() });

    const passwordHash = await bcrypt.hash(parsed.data.password, config.BCRYPT_ROUNDS);
    // Parameterized query: user input is data, never SQL syntax.
    const result = await pool.query(
      'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email, created_at',
      [parsed.data.email, passwordHash]
    );
    res.status(201).json({ user: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'An account with this email already exists.' });
    next(err);
  }
});

router.post('/login', authLimiter, async (req, res, next) => {
  try {
    const parsed = credentials.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid login data.' });

    const result = await pool.query(
      'SELECT id, email, password_hash FROM users WHERE email = $1',
      [parsed.data.email]
    );
    const user = result.rows[0];
    // Use the same response for unknown email and wrong password.
    const valid = user ? await bcrypt.compare(parsed.data.password, user.password_hash) : false;
    if (!valid) return res.status(401).json({ error: 'Invalid email or password.' });

    const token = jwt.sign(
      { sub: String(user.id), email: user.email },
      config.JWT_SECRET,
      { algorithm: 'HS256', expiresIn: config.JWT_EXPIRES_IN, issuer: 'security-starter' }
    );
    res.json({ token, tokenType: 'Bearer', expiresIn: config.JWT_EXPIRES_IN });
  } catch (err) {
    next(err);
  }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      'SELECT id, email, created_at FROM users WHERE id = $1',
      [Number(req.user.sub)]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'User not found.' });
    res.json({ user: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

export default router;
