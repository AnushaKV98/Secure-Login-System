import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { config } from './config.js';
import { initializeDatabase, pool } from './db.js';
import authRoutes from './routes/auth.js';
import { apiLimiter, errorHandler, notFound } from './middleware.js';

const app = express();

// Security headers. Keep Helmet enabled; tune CSP only for your actual frontend.
app.use(helmet());
app.use(cors({
  origin: config.CORS_ORIGIN,
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '10kb', strict: true }));
app.use(apiLimiter);

app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', authRoutes);
app.use(notFound);
app.use(errorHandler);

await initializeDatabase();
const server = app.listen(config.PORT, () => {
  console.log(`Secure API listening on port ${config.PORT}`);
});

async function shutdown(signal) {
  console.log(`${signal} received; shutting down`);
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
